
module.exports.AuthorRoutes = require("./Author")
module.exports.UserRoutes = require('./UserRoutes')